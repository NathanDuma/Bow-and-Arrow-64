# Bow and Arrow 64

A remake of the shareware game B&ARROW for the Nintendo 64.

How to play:

Use the DPAD or joystick to move the archer up and down. Hold A to prepare an arrow and let go of A to shoot. Become the greatest archer and complete all 12 levels!

If you play using an emulator, please use the DPAD since movement of the archer depends on the sensitivity of the joystick.

Made using the official Nintendo 64 SDK. This game uses the NuSystem with the sprite microcode.

Have fun!